## ----eval=FALSE---------------------------------------------------------------
#  createAnnotationPackage("zv9", dest="/path/to/package")

## ----eval=FALSE---------------------------------------------------------------
#  suppressPackageStartupMessages(library(BSgenome.Drerio.UCSC.danRer7))
#  
#  ## Genomic sequence and supported chromosomes
#  GENOME <- 'BSgenome.Drerio.UCSC.danRer7'
#  assign('GENOME', GENOME, .globals)
#  CHROMOSOMES <- as.character(1:25)
#  names(CHROMOSOMES) <- paste0("chr", CHROMOSOMES)
#  assign('CHROMOSOMES', CHROMOSOMES, .globals)
#  rm(GENOME)

## ----eval=FALSE---------------------------------------------------------------
#  vcf.files <- gsub("^chr(.+)$", "vcf_chr_\\1.vcf.gz", names(CHROMOSOMES))
#  vcf.files <- paste0(DBSNP.FTP.BASE, "zebrafish_7955/VCF/", vcf.files)

## ----eval=FALSE---------------------------------------------------------------
#  ## Define genomic regions
#  biomart.parameters <- list(
#    database.name = "ensembl",
#    dataset.name = "drerio_gene_ensembl",
#    required.columns = c(
#      "id" = "ensembl_gene_id",
#      "chromosome" = "chromosome_name",
#      "start" = "start_position",
#      "end" = "end_position",
#      "strand" = "strand",
#      "symbol" = "zfin_symbol",
#      "entrezID" = "entrezgene"))
#  cgi.url <- paste0(UCSC.FTP.BASE, "danRer7/database/cpgIslandExt.txt.gz")
#  logger.start("Region Annotation")
#  update.annot("regions", "region annotation", rnb.update.region.annotation,
#    biomart.parameters = biomart.parameters, cgi.download.url = cgi.url)
#  rm(biomart.parameters, cgi.url)
#  logger.completed()

## ----eval=FALSE---------------------------------------------------------------
#  createAnnotationPackage("zv9", dest="/path/to/package")

## ----eval=FALSE---------------------------------------------------------------
#  suppressPackageStartupMessages(library(RnBeads))
#  rnb.get.assemblies()

## ----eval=FALSE---------------------------------------------------------------
#  suppressPackageStartupMessages(library(biomaRt))
#  database.name <- "ensembl"
#  mart <- useMart(database.name)
#  datasets <- listMarts(mart)
#  head(datasets)

## ----eval=FALSE---------------------------------------------------------------
#  dataset.name <- "drerio_gene_ensembl"
#  mart <- useMart(database.name, dataset.name)
#  data.attributes <- unique(listAttributes(mart))
#  head(data.attributes)

## ----eval=FALSE---------------------------------------------------------------
#  data.attributes[grep("symbol", data.attributes[, 1]), ]

## ----eval=FALSE---------------------------------------------------------------
#  createAnnotationPackage.zv9 <- function() {
#  
#    suppressPackageStartupMessages(library(BSgenome.Drerio.UCSC.danRer7))
#  
#    ## Genomic sequence and supported chromosomes
#    GENOME <- 'BSgenome.Drerio.UCSC.danRer7'
#    assign('GENOME', GENOME, .globals)
#    CHROMOSOMES <- as.character(1:25)
#    names(CHROMOSOMES) <- paste0("chr", CHROMOSOMES)
#    assign('CHROMOSOMES', CHROMOSOMES, .globals)
#    rm(GENOME)
#  
#    ## Download SNP annotation
#    logger.start("SNP Annotation")
#    vcf.files <- gsub("^chr(.+)$", "vcf_chr_\\1.vcf.gz", names(CHROMOSOMES))
#    vcf.files <- paste0(DBSNP.FTP.BASE, "zebrafish_7955/VCF/", vcf.files)
#    update.annot("snps", "polymorphism information", rnb.update.dbsnp,
#      ftp.files = vcf.files)
#    logger.info(paste("Using:", attr(.globals[['snps']], "version")))
#    rm(vcf.files)
#    logger.completed()
#  
#    ## Define genomic regions
#    biomart.parameters <- list(
#      database.name = "ensembl",
#      dataset.name = "drerio_gene_ensembl",
#      required.columns = c(
#        "id" = "ensembl_gene_id",
#        "chromosome" = "chromosome_name",
#        "start" = "start_position",
#        "end" = "end_position",
#        "strand" = "strand",
#        "symbol" = "zfin_symbol",
#        "entrezID" = "entrezgene"))
#    cgi.url <- paste0(UCSC.FTP.BASE, "danRer7/database/cpgIslandExt.txt.gz")
#    logger.start("Region Annotation")
#    update.annot("regions", "region annotation", rnb.update.region.annotation,
#      biomart.parameters = biomart.parameters, cgi.download.url = cgi.url)
#    rm(biomart.parameters, cgi.url)
#    logger.completed()
#  
#    ## Define genomic sites
#    logger.start("Genomic Sites")
#    update.annot("sites", "CpG annotation", rnb.update.sites)
#    logger.completed()
#  
#    ## Create all possible mappings from regions to sites
#    logger.start("Mappings")
#    update.annot("mappings", "mappings", rnb.create.mappings)
#    logger.completed()
#  
#    ## Export the annotation tables
#    rnb.export.annotations.to.data.files()
#  }

